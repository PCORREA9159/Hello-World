<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"><html><head><META http-equiv="Content-Type" content="text/html; charset=utf-8"></head><body>


   
      
   
	
   <div>
      <table border="1">
         <tr bgcolor="#81a061">
            <th colspan="4">Compra Semanal</th>
           
         </tr>
         <tr bgcolor="#ffcc00">
            <th>Cantidad</th>
            <th>Descripcion</th>
            <th>P/u</th>
            <th>Total</th>
         </tr>
         <tr>
            <td>1</td>
            <td>Bolsa de papas de 10lbs</td>
            <td>$3.10</td>
            <td>$3.10</td>
         </tr>
         <tr>
           <td>5</td>
           <td>Guineos Maduros</td>
           <td>$1.15</td>
           <td>$5.75</td> 
         </tr>
         <tr>
           <td>5</td>
           <td>Latas de Habichuelas</td>
           <td>$0.39</td>
           <td>$1.95</td>
         </tr>
         <tr>
           <td>5</td>
           <td>Tomates</td>
           <td>$1.00</td>
           <td>$5.00</td>
         </tr>
         <tr>
           <td>2</td>
           <td>Libras de Lechuga</td>
           <td>$2.00</td>
           <td>$4.00</td>
         </tr>
         <tr> 
           <td>2</td>
           <td>Libras de Arroz</td>
           <td>$3.50</td>
           <td>$7.00</td>
         </tr>
         <tr>
           <td></td>
           <td></td>
           <td></td>
           <td>$0.00</td>
         <tr>
           <td></td>
           <td></td>
           <td>Sub total</td>
           <td>$26.80</td>
         </tr>
         <tr> 
           <td></td>
           <td></td>
           <td>Ivu 7%</td>
           <td>$1.88</td>
         </tr>
         <tr>
            <td></td>
            <td></td>
            <th>Total</th>
            <th>$28.68</th>
         </tr>
      </tr></table>
   </div>
	
</body></html>
